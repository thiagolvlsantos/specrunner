package org.specrunner.userguide.sbe.user;

public enum UserStatus {

	ENABLED("On"), DISABLED("Off");

	private String code;

	private UserStatus(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}
}
