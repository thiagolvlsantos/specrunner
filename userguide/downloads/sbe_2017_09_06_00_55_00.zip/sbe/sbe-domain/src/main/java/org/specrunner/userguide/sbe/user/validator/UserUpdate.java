package org.specrunner.userguide.sbe.user.validator;

public interface UserUpdate {
}