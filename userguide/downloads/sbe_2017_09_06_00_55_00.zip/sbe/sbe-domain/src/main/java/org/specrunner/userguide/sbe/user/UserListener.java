package org.specrunner.userguide.sbe.user;

import javax.persistence.PrePersist;

public class UserListener {

	@PrePersist
	public void beforeSave(User user) {
		if (user.getManager() == null) {
			user.setManager(Boolean.FALSE);
		}
		if (user.getStatus() == null) {
			user.setStatus(UserStatus.ENABLED);
		}
	}
}