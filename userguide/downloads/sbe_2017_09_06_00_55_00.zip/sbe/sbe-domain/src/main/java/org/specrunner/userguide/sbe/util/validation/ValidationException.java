package org.specrunner.userguide.sbe.util.validation;

import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;

import lombok.Getter;

@Getter
public class ValidationException extends RuntimeException {
	private final List<ConstraintViolation<?>> violations = new LinkedList<>();

	public ValidationException(String msg) {
		super(msg);
	}

	public <T> ValidationException(Set<ConstraintViolation<T>> violations) {
		for (ConstraintViolation<T> cv: violations) {
			this.violations.add(cv);
		}
	}
}
