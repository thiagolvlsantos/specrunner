package org.specrunner.userguide.sbe.util.security;

public class Roles {

	private Roles() {
	}

	public static final String ADMINISTRATOR = "admin";
	public static final String HAS_ADMINISTRATOR = "hasRole('" + ADMINISTRATOR + "')";
}
