package org.specrunner.userguide.sbe.user;

import java.util.List;

import javax.validation.groups.Default;

import org.specrunner.userguide.sbe.user.validator.UserUpdate;
import org.specrunner.userguide.sbe.util.validation.ValidationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
public class UserService {

	private @Autowired UserAuthorization userAuthorization;
	private @Autowired ValidationService validationService;
	private @Autowired UserRepository userRepository;

	public void save(User user) {
		userAuthorization.checkSaveRights(user);
		validationService.validate(user, Default.class); // default validations
		userRepository.save(user);
	}

	public void update(User user) {
		userAuthorization.checkUpdateRights(user);
		validationService.validate(user, UserUpdate.class, Default.class); // update validations
		userRepository.save(user);
	}

	public void delete(User u) {
		userRepository.delete(u);
	}

	public boolean exists(UserQuery query) {
		return userRepository.exists(query);
	}

	public List<User> query(UserQuery query) {
		return userRepository.query(query);
	}

	public Page<User> query(UserQuery query, Pageable pageable) {
		return userRepository.query(query, pageable);
	}
}