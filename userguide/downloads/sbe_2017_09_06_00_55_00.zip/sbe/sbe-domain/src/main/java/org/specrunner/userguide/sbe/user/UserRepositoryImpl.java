package org.specrunner.userguide.sbe.user;

import java.util.LinkedList;
import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.support.JpaPersistableEntityInformation;
import org.springframework.data.jpa.repository.support.QueryDslJpaRepository;
import org.springframework.stereotype.Repository;

import com.querydsl.core.types.ExpressionUtils;
import com.querydsl.core.types.Predicate;

@Repository
public class UserRepositoryImpl extends QueryDslJpaRepository<User, Long> implements UserRepositoryCustom {

	public UserRepositoryImpl(EntityManager entityManager) {
		super(new JpaPersistableEntityInformation<User, Long>(User.class, entityManager.getMetamodel()), entityManager);
	}

	@Override
	public boolean exists(UserQuery query) {
		return exists(toPredicate(query, true));
	}

	@Override
	public List<User> query(UserQuery query) {
		return findAll(toPredicate(query, false));
	}

	@Override
	public Page<User> query(UserQuery query, Pageable pageable) {
		return findAll(toPredicate(query, false), pageable);
	}

	private Predicate toPredicate(UserQuery query, boolean nameEquals) {
		List<Predicate> predicates = new LinkedList<>();
		if (query.getName() != null) {
			if (nameEquals) {
				predicates.add(QUser.user.name.equalsIgnoreCase(query.getName()));
			} else {
				predicates.add(QUser.user.name.containsIgnoreCase(query.getName()));
			}
		}
		if (query.getId() != null) {
			predicates.add(QUser.user.id.eq(query.getId()));
		}
		if (query.getStatus() != null) {
			predicates.add(QUser.user.status.in(query.getStatus()));
		}
		if (query.getCreationStart() != null) {
			predicates.add(QUser.user.creation.gt(query.getCreationStart()));
		}
		if (query.getCreationEnd() != null) {
			predicates.add(QUser.user.creation.lt(query.getCreationEnd()));
		}
		if (query.getCreator() != null) {
			predicates.add(QUser.user.creator.eq(query.getCreator()));
		}
		return ExpressionUtils.allOf(predicates); // AND
	}
}