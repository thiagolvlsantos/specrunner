package org.specrunner.userguide.sbe.user;

import org.specrunner.userguide.sbe.util.security.AuthorizationService;
import org.specrunner.userguide.sbe.util.security.Roles;
import org.specrunner.userguide.sbe.util.validation.ValidationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class UserAuthorization {
	public static final String UNAUTHORIZED_TO_CREATE_NEW_USERS = "Unauthorized to create new users.";

	private @Autowired AuthorizationService authorizationService;

	public void checkSaveRights(User user) {
		if (!authorizationService.hasRole(Roles.ADMINISTRATOR)) { // authorization
			throw new ValidationException(UNAUTHORIZED_TO_CREATE_NEW_USERS);
		}
	}

	public void checkUpdateRights(User user) {
		// nothing for while
	}
}