package org.specrunner.userguide.sbe.util.validation;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ValidationService {

	@Autowired
	protected Validator validator;

	public <T> void validate(T obj, Class<?>... groups) {
		Set<ConstraintViolation<T>> violations = validator.validate(obj, groups);
		if (!violations.isEmpty()) {
			throw new ValidationException(violations);
		}
	}
}
