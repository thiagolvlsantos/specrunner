package org.specrunner.userguide.sbe.user;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.joda.time.DateTime;
import org.specrunner.userguide.sbe.user.validator.UserUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.domain.Persistable;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@SuppressWarnings("serial")
@Entity
@Table(name = "USR_USER")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@EqualsAndHashCode(of = { "id", "name" })
@EntityListeners({ UserListener.class, AuditingEntityListener.class })
public class User implements Persistable<Long> {

	public static final int NAME_MIN_SIZE = 2;
	public static final int NAME_MAX_SIZE = 100;
	public static final int CREATOR_MAX_SIZE = 40;

	@Id
	@Column(name = "USR_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@NotNull(groups = { UserUpdate.class }) // ids on updates must exists
	private Long id;

	@Column(name = "USR_IB_MANAGER", nullable = false) // not appears in specifications (if not required)
	@NotNull(groups = { UserUpdate.class })
	private Boolean manager;

	@NotNull(message = "User name is required.")
	@Size(min = NAME_MIN_SIZE, max = NAME_MAX_SIZE)
	@Column(name = "USR_NM_NAME", nullable = false, unique = true, length = NAME_MAX_SIZE)
	private String name;

	@Column(name = "USR_CD_STATUS", nullable = false)
	@NotNull(groups = { UserUpdate.class }) // cannot set status to null!
	private UserStatus status;

	@Column(name = "USR_DH_CREATION", nullable = false)
	@CreatedDate
	private DateTime creation;

	@Column(name = "USR_DS_CREATOR", nullable = false, length = CREATOR_MAX_SIZE)
	@CreatedBy
	private String creator;

	@Override
	public boolean isNew() {
		return id == null;
	}
}