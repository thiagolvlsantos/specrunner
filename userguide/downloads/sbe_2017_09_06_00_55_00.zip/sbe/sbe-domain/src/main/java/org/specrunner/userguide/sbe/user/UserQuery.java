package org.specrunner.userguide.sbe.user;

import java.util.List;

import org.joda.time.DateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserQuery {

	private Long id;
	private String name;
	private List<UserStatus> status;
	private DateTime creationStart;
	private DateTime creationEnd;
	private String creator;
}
