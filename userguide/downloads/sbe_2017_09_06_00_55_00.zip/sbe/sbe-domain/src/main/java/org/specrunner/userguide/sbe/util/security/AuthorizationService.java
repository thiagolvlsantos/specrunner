package org.specrunner.userguide.sbe.util.security;

import java.util.Collection;
import java.util.Set;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

@Service
public class AuthorizationService {

	public void anonymous() {
		SecurityContextHolder.getContext().setAuthentication(null);
	}

	@SuppressWarnings("serial")
	public void personate(final String login, final String... roles) {
		Authentication a = new Authentication() {
			private boolean authenticated = true;

			@Override
			public String getName() {
				return login;
			}

			@Override
			public void setAuthenticated(boolean authenticated) {
				this.authenticated = authenticated;
			}

			@Override
			public boolean isAuthenticated() {
				return authenticated;
			}

			@Override
			public Object getPrincipal() {
				return login;
			}

			@Override
			public Object getDetails() {
				return login;
			}

			@Override
			public Object getCredentials() {
				return roles;
			}

			@Override
			public Collection<? extends GrantedAuthority> getAuthorities() {
				return AuthorityUtils.createAuthorityList(roles);
			}
		};
		SecurityContextHolder.getContext().setAuthentication(a);
	}

	public boolean hasRole(String... roles) {
		if (roles == null) {
			return false;
		}
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication == null || !authentication.isAuthenticated()) {
			return false;
		}
		Set<String> tmp = AuthorityUtils.authorityListToSet(authentication.getAuthorities());
		for (String p : roles) {
			if (tmp.contains(p)) {
				return true;
			}
		}
		return false;
	}

	public boolean isCurrent(String login) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication == null || !authentication.isAuthenticated()) {
			return false;
		}
		return authentication.getPrincipal().equals(login);
	}
}