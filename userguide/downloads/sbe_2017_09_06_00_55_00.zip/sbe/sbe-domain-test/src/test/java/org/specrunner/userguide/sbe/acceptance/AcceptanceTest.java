package org.specrunner.userguide.sbe.acceptance;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.validation.ConstraintViolation;

import org.junit.runner.RunWith;
import org.specrunner.SRServices;
import org.specrunner.comparators.core.AbstractComparatorTime;
import org.specrunner.features.IFeatureManager;
import org.specrunner.junit.SRRunnerSpringScenario;
import org.specrunner.result.IResult;
import org.specrunner.result.IResultFilter;
import org.specrunner.result.IResultSet;
import org.specrunner.result.status.Warning;
import org.specrunner.sql.PluginConnection;
import org.specrunner.sql.negative.PluginDbms;
import org.specrunner.userguide.sbe.util.validation.ValidationException;
import org.specrunner.util.aligner.core.DefaultAlignmentException;
import org.specrunner.util.string.IStringNormalizer;
import org.specrunner.util.xom.core.PresentationCompare;
import org.specrunner.util.xom.core.PresentationException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import com.google.common.io.Files;

import lombok.extern.slf4j.Slf4j;

@RunWith(SRRunnerSpringScenario.class)
@SpringBootTest
@ActiveProfiles({ "test" })
@Slf4j
public abstract class AcceptanceTest {

	static boolean schemaDone = false;

	@Value("${spring.datasource.d1.driver-class-name}")
	private String driver;

	@Value("${spring.datasource.d1.url}")
	private String urlD1;

	@Value("${spring.datasource.d1.username}")
	private String username;

	@Value("${spring.datasource.d1.password}")
	private String password;

	@Value("${spring.datasource.d2.url}")
	private String urlD2;

	protected IStringNormalizer normalizer;
	
	@PostConstruct
	public void databaseSetup() throws Exception {
		properties();
		schemaSetup();
		connectionSetup();
	}

	private void properties() {
		IFeatureManager fm = SRServices.getFeatureManager();
		fm.add(AbstractComparatorTime.FEATURE_TOLERANCE, 10 * 60 * 1000L);
		fm.add(IResultSet.FEATURE_RESULT_FILTER, new IResultFilter() {
			@Override
			public boolean accept(IResult result) {
				return result.getStatus() != Warning.INSTANCE;
			}
		});
		normalizer = SRServices.get(IStringNormalizer.class);
	}

	private void schemaSetup() throws Exception {
		if (schemaDone) {
			return;
		}
		schemaDone = true;
		log.info("\n=========== SCHEMA =============\n");
		String manual = "src/test/resources/sgbd_manual.sql";
		String drop = "src/test/resources/sgbd_drop.sql";
		String create = "src/test/resources/sgbd_create.sql";
		String done = "src/test/resources/sgbd_final.sql";

		try (FileWriter fw = new FileWriter(done)) {
			String[] partes = new String[] { manual, drop, create };
			for (String s : partes) {
				try (BufferedReader br = new BufferedReader(new FileReader(new File(s)))) {
					String input = br.readLine();
					while (input != null) {
						fw.write(input + ";\n");
						input = br.readLine();
					}
				}
			}
		}
		Files.copy(new File(done), new File("target/classes/sgbd_final.sql"));
	}

	private void connectionSetup() {
		IFeatureManager fm = SRServices.getFeatureManager();
		String system = driver + "|" + urlD1 + "|" + username + "|" + password;
		log.info(system);
		String reference = driver + "|" + urlD2 + "|" + username + "|" + password;
		log.info(reference);
		fm.add(PluginDbms.FEATURE_SYSTEM, system);
		fm.add(PluginDbms.FEATURE_REFERENCE, reference);
		fm.add(PluginConnection.FEATURE_REUSE, true);
	}
	
	protected boolean normalizedComparison(String expected, String received) {
		return normalizer.normalize(expected).equals(normalizer.normalize(received));
	}
	
	protected void compareMessage(String msg, ValidationException e) throws PresentationException {
		String message = e.getMessage();
		if (message != null) {
			if (!normalizedComparison(msg, message)) {
				throw new PresentationException(new DefaultAlignmentException(msg, message));
			}
		} else {
			List<ConstraintViolation<?>> violations = e.getViolations();
			boolean found = false; 
			for (ConstraintViolation<?> cv: violations) {
				if(normalizedComparison(msg, cv.getMessage())) {
					found = true;
				}
			}
			if(!found) {
				throw new PresentationException(new PresentationCompare(msg,violations));
			}
		}
	}
}
