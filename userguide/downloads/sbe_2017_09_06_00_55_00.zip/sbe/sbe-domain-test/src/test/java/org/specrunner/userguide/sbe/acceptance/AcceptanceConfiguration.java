package org.specrunner.userguide.sbe.acceptance;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.h2.tools.Server;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;

@Profile("test")
@Configuration
public class AcceptanceConfiguration {

	@Bean
	@Primary
	@ConfigurationProperties(prefix = "spring.datasource.d1")
	public DataSource d1() {
		return DataSourceBuilder.create().build();
	}

	@Bean
	@ConfigurationProperties(prefix = "spring.datasource.d2")
	public DataSource d2() {
		return DataSourceBuilder.create().build();
	}

	@Bean
	public Server h2WebServer() throws SQLException {
		return Server.createWebServer("-web", "-webAllowOthers", "-webPort", "9001").start();
	}
}