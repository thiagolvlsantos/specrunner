package org.specrunner.userguide.sbe.acceptance.domain.users.bad;

import org.specrunner.userguide.sbe.acceptance.domain.users.UserRegistrationTests;
import org.specrunner.userguide.sbe.util.security.Roles;
import org.specrunner.userguide.sbe.util.validation.ValidationException;
import org.specrunner.util.xom.core.PresentationException;

public class UserRegistrationTestsEx1 extends UserRegistrationTests {

	public void namedAdmin(String login) {
		authorizationService.personate(login, Roles.ADMINISTRATOR);
	}

	public void message(String msg) throws PresentationException {
		try {
			save();
			throw new IllegalStateException("Save should fail!");
		} catch (ValidationException e) {
			compareMessage(msg, e);
		}
	}
}