package org.specrunner.userguide.sbe.acceptance.converters;

import org.specrunner.converters.core.ConverterEnumTemplate;
import org.specrunner.userguide.sbe.user.UserStatus;

@SuppressWarnings("serial")
public class ConverterUserStatus extends ConverterEnumTemplate {

	public ConverterUserStatus() {
		super(UserStatus.class, "getCode");
	}
}
