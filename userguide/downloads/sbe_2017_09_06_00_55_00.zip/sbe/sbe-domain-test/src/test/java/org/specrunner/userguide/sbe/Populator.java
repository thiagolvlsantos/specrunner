package org.specrunner.userguide.sbe;

import javax.annotation.PostConstruct;

import org.specrunner.userguide.sbe.user.User;
import org.specrunner.userguide.sbe.user.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
@Profile("populator")
public class Populator {
	private @Autowired UserService userService;

	@PostConstruct
	@Transactional
	public void popular() {
		for (int i = 1; i <= 15; i++) {
			userService.save(User.builder().name("Name " + i).build());
		}
		log.info("Done!");
	}
}
