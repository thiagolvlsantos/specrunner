package org.specrunner.userguide.sbe.acceptance.domain;

import org.specrunner.userguide.sbe.acceptance.AcceptanceTest;

public class ProfileTests extends AcceptanceTest {
}