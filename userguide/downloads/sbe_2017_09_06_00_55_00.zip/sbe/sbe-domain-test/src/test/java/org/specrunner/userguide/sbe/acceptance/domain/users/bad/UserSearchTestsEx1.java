package org.specrunner.userguide.sbe.acceptance.domain.users.bad;

import org.specrunner.userguide.sbe.acceptance.domain.users.UserSearchTests;

public class UserSearchTestsEx1 extends UserSearchTests {
}