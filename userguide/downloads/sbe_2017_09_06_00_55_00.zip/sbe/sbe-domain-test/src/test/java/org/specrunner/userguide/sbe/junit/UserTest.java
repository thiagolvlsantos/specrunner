package org.specrunner.userguide.sbe.junit;

import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.Test;
import org.specrunner.userguide.sbe.user.User;
import org.specrunner.userguide.sbe.user.UserStatus;

public class UserTest {

	@Test
	public void emptyIsNew() {
		Assert.assertTrue(new User().isNew());
	}

	@Test
	public void emptyNotIsNew() {
		Assert.assertFalse(User.builder().id(1L).build().isNew());
	}

	@Test
	public void emptyEquals() {
		User u = new User();

		// Useless: coverage != fail safe
		Assert.assertEquals(u, u);
	}

	@Test
	public void emptyToString() {
		User u = new User();

		// Useless: coverage != Fail safe
		Assert.assertEquals(u.toString(), u.toString());
	}

	@Test
	public void allPlusGets() {
		DateTime now = DateTime.now();
		User u = new User(1L, Boolean.TRUE, "John", UserStatus.ENABLED, now, "mylogin");

		Assert.assertEquals((long) u.getId(), 1);
		Assert.assertEquals(u.getName(), "John");
		Assert.assertEquals(u.getManager(), Boolean.TRUE);
		Assert.assertEquals(u.getStatus(), UserStatus.ENABLED);
		Assert.assertEquals(u.getCreation(), now);
		Assert.assertEquals(u.getCreator(), "mylogin");
	}

	@Test
	public void emptyPlusSet() {
		DateTime now = DateTime.now();
		User u = new User();
		u.setId(1L);
		u.setName("John");
		u.setManager(Boolean.TRUE);
		u.setStatus(UserStatus.ENABLED);
		u.setCreation(now);
		u.setCreator("mylogin");

		Assert.assertEquals((long) u.getId(), 1);
		Assert.assertEquals(u.getName(), "John");
		Assert.assertEquals(u.getManager(), Boolean.TRUE);
		Assert.assertEquals(u.getStatus(), UserStatus.ENABLED);
		Assert.assertEquals(u.getCreation(), now);
		Assert.assertEquals(u.getCreator(), "mylogin");
	}

	@Test
	public void builder() {
		DateTime now = DateTime.now();
		User u = User.builder().id(1L).name("John").status(UserStatus.ENABLED).creation(now).creator("mylogin").build();
		Assert.assertEquals((long) u.getId(), 1);
		Assert.assertEquals(u.getName(), "John");
		Assert.assertEquals(u.getStatus(), UserStatus.ENABLED);
		Assert.assertEquals(u.getCreation(), now);
		Assert.assertEquals(u.getCreator(), "mylogin");
	}

	@Test
	public void equals() {
		DateTime now = DateTime.now();
		User u = User.builder().id(1L).name("John").status(UserStatus.ENABLED).creation(now).creator("mylogin").build();
		User y = User.builder().id(1L).name("John").status(UserStatus.DISABLED).build();
		Assert.assertTrue(u.equals(y));
	}

	@Test
	public void notEquals() {
		DateTime now = DateTime.now();
		User u = User.builder().id(1L).name("John").status(UserStatus.ENABLED).creation(now).creator("mylogin").build();
		User y = User.builder().id(1L).name("Jane").build();
		Assert.assertFalse(u.equals(y));
	}
}