package org.specrunner.userguide.sbe.acceptance.domain.users;

import org.specrunner.annotations.BeforeScenario;
import org.specrunner.converters.Converter;
import org.specrunner.plugins.core.language.Synonyms;
import org.specrunner.userguide.sbe.acceptance.AcceptanceTestChanges;
import org.specrunner.userguide.sbe.user.User;
import org.specrunner.userguide.sbe.user.User.UserBuilder;
import org.specrunner.userguide.sbe.user.UserAuthorization;
import org.specrunner.userguide.sbe.user.UserService;
import org.specrunner.userguide.sbe.user.UserStatus;
import org.specrunner.userguide.sbe.util.security.AuthorizationService;
import org.specrunner.userguide.sbe.util.security.Roles;
import org.specrunner.userguide.sbe.util.validation.ValidationException;
import org.specrunner.util.xom.core.PresentationCompare;
import org.specrunner.util.xom.core.PresentationException;
import org.springframework.beans.factory.annotation.Autowired;

public class UserRegistrationTests extends AcceptanceTestChanges {

	protected @Autowired AuthorizationService authorizationService;
	protected @Autowired UserService userService;
	protected UserBuilder userBuilder;
	protected User user;

	@BeforeScenario
	public void before() {
		userBuilder = User.builder();
		user = null;
	}

	public void anonymously() {
		authorizationService.anonymous();
	}

	public void named(String name) {
		userBuilder.name(name);
	}

	protected void save() {
		user = userBuilder.build();
		userService.save(user);
	}

	public boolean forbidden() {
		try {
			save();
			return false;
		} catch (ValidationException e) {
			return UserAuthorization.UNAUTHORIZED_TO_CREATE_NEW_USERS.equals(e.getMessage());
		}
	}

	public void asAnOrdinaryUser() {
		authorizationService.personate("anyuser"); // without roles
	}

	@Synonyms("an administrator") // different expressions to the same behavior
	public void asAnAdministrator() {
		authorizationService.personate("anyadmin", Roles.ADMINISTRATOR);
	}

	public boolean succeeded() {
		try {
			save();
			return true;
		} catch (ValidationException e) {
			return false;
		}
	}

	public boolean aborts() {
		try {
			save();
			return false; // not aborted
		} catch (ValidationException e) {
			return true; // aborted
		}
	}

	public void status(@Converter(name = "us") UserStatus status) {
		userBuilder.status(status);
	}

	@Synonyms("status will be $quote")
	public void withStatus(@Converter(name = "us") UserStatus status) throws PresentationException {
		save();
		if (user.getStatus() != status) {
			throw new PresentationException(new PresentationCompare(status, user.getStatus()));
		}
	}
}