package org.specrunner.userguide.sbe.acceptance;

import org.specrunner.SRServices;
import org.specrunner.annotations.BeforeScenario;
import org.specrunner.annotations.SRScenarioListeners;
import org.specrunner.sql.negative.DatabaseScenarioListener;

@SRScenarioListeners(value = { DatabaseScenarioListener.class })
public abstract class AcceptanceTestChanges extends AcceptanceTest {

	@BeforeScenario
	public void clearMocks() {
		SRServices.getObjectManager().clear();
	}
}
