package org.specrunner.userguide.sbe.acceptance.converters;

import org.specrunner.converters.core.ConverterEnumValueTemplate;
import org.specrunner.userguide.sbe.user.UserStatus;

@SuppressWarnings("serial")
public class ConverterUserStatusValue extends ConverterEnumValueTemplate {

	public ConverterUserStatusValue() {
		super(UserStatus.class, "getCode", "ordinal");
	}
}
