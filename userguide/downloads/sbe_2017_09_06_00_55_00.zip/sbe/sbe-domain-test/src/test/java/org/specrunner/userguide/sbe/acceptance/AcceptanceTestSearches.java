package org.specrunner.userguide.sbe.acceptance;

import org.specrunner.annotations.SRScenarioListeners;
import org.specrunner.sql.negative.DatabaseScenarioCompareListener;

@SRScenarioListeners(value = { DatabaseScenarioCompareListener.class })
public abstract class AcceptanceTestSearches extends AcceptanceTest {
}