package org.specrunner.userguide.sbe.acceptance;

import org.specrunner.userguide.sbe.acceptance.AcceptanceTest;

public class SystemTests extends AcceptanceTest {
}