package org.specrunner.userguide.sbe.integration;

import java.util.Arrays;
import java.util.List;

import org.joda.time.DateTime;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.specrunner.userguide.sbe.user.User;
import org.specrunner.userguide.sbe.user.UserQuery;
import org.specrunner.userguide.sbe.user.UserService;
import org.specrunner.userguide.sbe.user.UserStatus;
import org.specrunner.userguide.sbe.util.security.AuthorizationService;
import org.specrunner.userguide.sbe.util.security.Roles;
import org.specrunner.userguide.sbe.util.validation.ValidationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.test.context.junit4.SpringRunner;

import lombok.extern.slf4j.Slf4j;

@RunWith(SpringRunner.class)
@SpringBootTest
@Slf4j
public class UserServiceIntegrationTest {

	private @Autowired AuthorizationService authorization;
	private @Autowired UserService service;
	private static long index = 0;

	@Before
	public void setup() {
		log.info("Setup");
		authorization.personate("mylogin", Roles.ADMINISTRATOR);
		service.save(User.builder().name("John").build());
		service.save(User.builder().name("Jane").status(UserStatus.DISABLED).build());
		index++;
	}

	@After
	public void clear() {
		for (User u : service.query(UserQuery.builder().build())) {
			service.delete(u);
		}
	}

	@Test
	public void all() {
		List<User> tmp = service.query(new UserQuery());
		log.info(tmp.toString());
		Assert.assertEquals(2, tmp.size());
		Assert.assertEquals("John", tmp.get(0).getName());
		Assert.assertEquals("Jane", tmp.get(1).getName());
	}

	@Test
	public void allPage() {
		Page<User> tmp = service.query(UserQuery.builder().build(), null);
		Assert.assertEquals(2, tmp.getTotalElements());
		Assert.assertEquals(1, tmp.getTotalPages());
		List<User> content = tmp.getContent();
		Assert.assertEquals("John", content.get(0).getName());
		Assert.assertEquals("Jane", content.get(1).getName());
	}

	@Test
	public void byId() {
		List<User> tmp = service.query(UserQuery.builder().id((index * 2) - 1).build()); // fragile
		Assert.assertEquals(1, tmp.size());
		Assert.assertEquals("John", tmp.get(0).getName());
	}

	@Test
	public void byName() {
		List<User> tmp = service.query(UserQuery.builder().name("John").build());
		Assert.assertEquals(1, tmp.size());
		Assert.assertEquals("John", tmp.get(0).getName());
	}

	@Test
	public void byStatus() {
		List<User> tmp = service.query(UserQuery.builder().status(Arrays.asList(UserStatus.DISABLED)).build());
		Assert.assertEquals(1, tmp.size());
		Assert.assertEquals("Jane", tmp.get(0).getName());
	}

	@Test
	public void byNameStatus() {
		List<User> tmp = service
				.query(UserQuery.builder().name("Jane").status(Arrays.asList(UserStatus.DISABLED)).build());
		Assert.assertEquals(1, tmp.size());
		Assert.assertEquals("Jane", tmp.get(0).getName());
	}

	@Test
	public void byCreation() {
		List<User> tmp = service.query(UserQuery.builder().creationStart(DateTime.now().minusMinutes(1))
				.creationEnd(DateTime.now().plusMinutes(1)).build());
		Assert.assertEquals(2, tmp.size());
	}

	@Test
	public void byCreator() {
		List<User> tmp = service.query(UserQuery.builder().creator("mylogin").build());
		Assert.assertEquals(2, tmp.size());
		Assert.assertEquals("Jane", tmp.get(1).getName());
	}

	@Test
	public void exists() {
		Assert.assertTrue(service.exists(UserQuery.builder().name("John").build()));
	}

	@Test
	public void save() {
		service.save(User.builder().name("Tarzan").build());
	}

	@Test(expected = ValidationException.class)
	public void saveWithoutName() {
		service.save(User.builder().build());
	}

	@Test(expected = ValidationException.class)
	public void saveLittleName() {
		service.save(User.builder().name("a").build());
	}

	@Test(expected = ValidationException.class)
	public void saveBigName() {
		service.save(User.builder().name(
				"0123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789")
				.build());
	}

	@Test
	public void update() {
		User tmp = service.query(UserQuery.builder().name("John").build()).get(0);
		Assert.assertNotNull(tmp);
		tmp.setName("Ringo");
		service.update(tmp);
		tmp = service.query(UserQuery.builder().name("Ringo").build()).get(0);
		Assert.assertNotNull(tmp);
		Assert.assertEquals("Ringo", tmp.getName());
	}

	@Test(expected = ValidationException.class)
	public void updateWithoutId() {
		authorization.personate("mylogin", Roles.ADMINISTRATOR);
		service.update(User.builder().build());
	}

	@Test(expected = ValidationException.class)
	public void saveWithoutAdmin() {
		authorization.personate("anylogin");
		service.save(User.builder().name("Erick").build());
	}
}