package org.specrunner.userguide.sbe.acceptance.domain.users;

import java.util.Arrays;
import java.util.List;

import org.joda.time.DateTime;
import org.specrunner.annotations.BeforeScenario;
import org.specrunner.converters.Converter;
import org.specrunner.userguide.sbe.acceptance.AcceptanceTestSearches;
import org.specrunner.userguide.sbe.user.User;
import org.specrunner.userguide.sbe.user.UserQuery;
import org.specrunner.userguide.sbe.user.UserQuery.UserQueryBuilder;
import org.specrunner.userguide.sbe.user.UserService;
import org.specrunner.userguide.sbe.user.UserStatus;
import org.springframework.beans.factory.annotation.Autowired;

public class UserSearchTests extends AcceptanceTestSearches {

	protected @Autowired UserService userService;
	protected UserQueryBuilder builder;

	@BeforeScenario
	public void before() {
		builder = UserQuery.builder();
	}

	public void id(Long id) {
		builder.id(id);
	}

	public void name(String name) {
		builder.name(name);
	}

	public void status(@Converter(name = "us") UserStatus... status) {
		builder.status(Arrays.asList(status));
	}

	public void creationFromUpTo(@Converter(name = "dtc") DateTime start, @Converter(name = "dtc") DateTime end) {
		builder.creationStart(start);
		builder.creationEnd(end);
	}

	public void creator(String creator) {
		builder.creator(creator);
	}

	public List<User> result() {
		return userService.query(builder.build());
	}

	public User is() {
		return result().get(0);
	}

	public boolean nothingIsFound() {
		return result().isEmpty();
	}
}