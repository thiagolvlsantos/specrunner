$(document).ready(function(){
	
	createIndex(); // create index
	addCheck(); // format header
	addIndex("#index"); // index creation
	addTrack(); // track
	addCls(); // format header
	addTop(); // format header
	markTables([".prepare",".verify",".verifyObjects",".roles"]) // any interesting table
	
	// disposeable
	addHistory();
	markTables([".history"]);
});

function addTrack() {
	process("track",["#track"], function(i,e){
		var values = e.attr("path").split(",");
		for(var i = 0; i < values.length; i++){
			e.append((i>0?" &rarr; ":" ")+"<a href='"+"../".repeat(values.length-i)+values[i]+"Tests.html'>"+values[i]+"</a> ");
		}
	});
}

function process(alias,selection,callback) {
	for(var i = 0; i < selection.length; i++) {
		$(selection[i]).each(function() {
			if(!$(this).data(alias+i)) {
				callback(i,$(this),selection[i]);
				$(this).data(alias+i,true);
			}
		});
	}
}

function addCls() {
	processHeaders("cls", function(i,e) {
		e.addClass("header");
	});
}

function processHeaders(alias,callback) {
	process(alias,["h1","h2","h3"], callback);
}

function addTop() {
	processHeaders("top", function(i,e) {
		e.append(" <span style='font-size:10px;'>(<a href='#' onclick='window.scrollTo(0,0);return false;'>Top</a>)</span>");
	});
}

function addCheck() {
	process("check", [".title"], function(i,e) {
		e.prepend(" [&#10004;] "); //&#10004; - check mark
	});
}

function markTables(selector) {
	process("table",selector, function(i, e, s){
		e.addClass("table table-striped table-bordered table-hover table-sm");
		$("thead", e).each(function(){
			$(this).addClass("thead-inverse");
		})
	});
}

function addIndex(placeholder) {
	var index = $(placeholder);
	if(index.length == 0){
		return;
	}
	if(!index.data("index")) {
		var header = index.attr("title");
		if(!header){
			header = "Examples";
		}
		var base = index.attr("header");
		if(!base) {
			base = "h3";
		}
		index.prepend("<h2 id='index_ignore'><a name='index_header'>"+header+"</a></h2>");
		var cindex = $("#index_ignore");
		cindex.data("index",true);
		
		index.append("<blockquote id='index_titles'>");
		var bindex = $("#index_titles");
		
		bindex.append("<ul id='index_list'>");
		var uindex = $("#index_list");
		
		var countIndex = 0;
		$(base).each(function(i) {
			if(!$(this).data("index") && $(this).is(":visible")) {
				uindex.append("<li><a href='#"+base+""+i+"'>"+$(this).text()+"</a></li>"); // index entry

				$(this).prepend("<a name='"+base+""+i+"'></a>"); // old header index
				$(this).append(" <span style='font-size:10px;'>(<a href='#index_header'>"+header+"</a>)</span>");
				
				$(this).data("index",true);
				countIndex++;
			}
		});
		bindex.append("</ul>");
		index.append("</blockquote>");
		index.data("index",true);
		if(countIndex == 0){
			index.remove();
		}
	}
}

function createIndex(){
	var content = [$("<div><h2 ignore='true'>Contents</h2></div>")];
	var max = 1;
	var current = 0;
	var serial = 0;
	process("newIndex",["h2, h3, h4"],function(i,e) {
		var tag = e.prop("localName");
		var level = tag.substring(1);
		var prefix = "&nbsp;&nbsp;&nbsp;&nbsp;".repeat(level)+"&bull; ";
		e.prepend("<a name='serial"+serial+"'></a>");
		var item = $("<div>"+prefix + "<a href='#serial"+serial+"'>"+e.text()+"</a>"+"</div>");
		if(current < level) {
			content.push(item);
		} else if (current > level) {
			var pop = content.pop();
			var top = content[content.length-1];
			top.append(pop);
			top.append(item);
		} else {
			content[content.length-1].append(item);
		}
		current = level;
		serial++;
	});
	console.log(content);
	$("#novoIndex").append(content);
}

function addHistory() {
	$("table.history").each(function(i) {
		if(!$(this).data("done")) {
			var table = $(this);
			var s = table.data("show");
			$("caption",table).prepend("<input type='button' id='bthist' value=' - ' style='width:30px;'> ");
			$("caption",table).append(" <span style='font-size:8px;'>(<a href='#' onclick='window.scrollTo(0,0);return false;'>Top</a>)</span>");
			var his = $("#bthist");
			his.click(function(){
				$("tr",table).each(function(){
					if(!table.data("show")){
						$(this).show();
						his.attr("value"," - ");
					} else {
						$(this).hide();
						his.attr("value"," + ");
					}
				});
				table.data("show",!table.data("show"));
			});
			table.data("show",!s);
			table.data("done",true);
			$("#bthist").each(function(i) {
				$(this).click();
			});
		}
	});
}