drop table sbe.usr_user if exists
